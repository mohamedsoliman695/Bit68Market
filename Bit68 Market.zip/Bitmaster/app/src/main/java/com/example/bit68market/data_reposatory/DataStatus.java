package com.example.bit68market.data_reposatory;

public interface DataStatus {

     void onSucess();

     void onFailure();
}
